package mrfabian.pictureforproject;

import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Intent;
import android.graphics.Bitmap;

import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {
    //Displays image resources
    ImageView ImageView;
//    LinkedList<Bitmap> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //set the main activity
        setContentView(R.layout.activity_main);

        //button linked with the one on the screen
        Button btmCamera = (Button) findViewById(R.id.btnCamera);

        //blank space on the screen linked
        ImageView= (ImageView) findViewById(R.id.imageView);

        //represent the action when the button is clicked
        btmCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //switch the original screen to the camera  screen
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                //start the camera
                startActivityForResult(intent, 0);
            }
        });
    }

    //represent the result of the camera, saving the picture
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //represent the image itself
        Bitmap photo = (Bitmap)data.getExtras().get("data");

        //set the screen to display the image
        ImageView.setImageBitmap(photo);
        //this is where we can store the images in the hashmap, or call the OCR function and then
        //store the info extracted from the images.

        //for example!!
//        list.add(photo);

    }

}
