package main;

import java.lang.*;
import java.util.*;
import java.io.*;
import java.io.BufferedWriter;
import java.nio.file.*;
import java.nio.file.Paths;
import java.lang.NullPointerException;
import java.lang.IndexOutOfBoundsException;


class Database{

	private List<List<Information>> myList = new ArrayList<>();
	// Creates store with an empty ArrayList
	public void createCoupon(String storeName, String image, String expirationDate, String couponNumber){
            Information info = new Information(storeName, image, expirationDate, couponNumber);
            // Adds more Information objects into the second ArrayList
            if(getIndexOfStore(storeName) != -1){
		myList.get(getIndexOfStore(storeName)).add(info);
            }
            else{
		// Creates an empty list at the max index of the first ArrayList
		ArrayList<Information> emptyList = new ArrayList<>();
		myList.add(myList.size(), emptyList);
		// Adds Information object inside the empty ArrayList
		myList.get((myList.size()-1)).add(info);
            }
	}
        // Deletes store based on store name
        public boolean deleteStore(String storeName){
            if(getIndexOfStore(storeName) == -1){ return false; }
            myList.remove(getIndexOfStore(storeName));
            return true;
        }
        // Delete the index of the store
        public boolean deleteStore(int index){
           if(checkStoreIndex(index)){
                myList.remove(index);
                return true;
            }
            return false;
        }
        // Deletes the coupon from the store based on the coupon number
        public boolean deleteCoupon(String storeName, String couponNumber){
            if(getIndexOfStore(storeName) == -1){ return false; }
            if(getIndexOfCoupon(couponNumber) == -1){ return false; }
            myList.get(getIndexOfStore(storeName)).remove(getIndexOfCoupon(couponNumber));
            return true;
        }
        // Delete the index of the coupon corresponding to the store
        public boolean deleteCoupon(int storeIndex, int couponIndex){
            if(checkCouponIndex(storeIndex,couponIndex)){
                myList.get(storeIndex).remove(couponIndex);
                return true;
            }
            return false;
        }
        // Read entries from file and places it into the ArrayList
	public void read(String fileName){
		String fileLine = "";
		try{
                    FileReader fileReader = new FileReader(fileName);
                    BufferedReader buffReader = new BufferedReader(fileReader);
                    // Read until end of file
                    while(( fileLine = buffReader.readLine() ) != null ){
                        // Split the file line into tokens
                        String[] tokens = fileLine.split(" ");
                        int offset = 0;
                        int numberOfTokens = tokens.length;
                        String storeName = tokens[0];
                        while(numberOfTokens > 4){
                            storeName = storeName + " " + tokens[++offset];
                            --numberOfTokens;
                        }
                        String image = tokens[++offset];
                        String expirationDate = tokens[++offset];
                        String couponNumber = tokens[++offset];
                        createCoupon(storeName, image, expirationDate, couponNumber);
                    }
		}
		catch(IOException ex) {
                    ex.printStackTrace();
		}
	}
        public void write(String fileName){
		try{
		FileWriter fileWriter = new FileWriter(fileName);
		BufferedWriter buffWrite = new BufferedWriter(fileWriter);
		// Range based loop to go through list
                for(List<Information> entry : myList){
                    for(Information info : entry){
                        buffWrite.write(info.toString());
                        buffWrite.newLine();
                    }
                }
		// Closes buffer
		buffWrite.close();
		}
		// Not really sure what this does. Need a catch statement.
		catch(IOException ex){ 
			ex.printStackTrace(); 
		}
	}

        
        /*                                                                          */
        /*                       Helper Functions                                   */
        /*                                                                          */
        
        // Helper function to check if the index is within range 
        public boolean checkStoreIndex(int index){
            return index < myList.size();
        }
        // Helper function to check if the store index and coupon index is within range
        public boolean checkCouponIndex(int storeIndex, int couponIndex){
            return checkStoreIndex(storeIndex) && couponIndex < myList.get(storeIndex).size();
        }
        // Helper function that returns the position of the list where the store name was found
        // Returns -1 if not found
	public int getIndexOfStore(String storeName){
            if(myList.isEmpty()){ return -1; }
            for(int index = 0; index < myList.size(); index++){
		// Checks the first element of the second ArrayList to see if the store name is found
		if(myList.get(index).get(0).getStoreName().equals(storeName)){
			return index;
		}
            }
            return -1;
	}
        // Helper function that returns the position of where coupon number was found
        // Returns -1 if not found
        public int getIndexOfCoupon(String couponNumber){
            if(myList.isEmpty()){ return -1; }
            for(int firstArray = 0; firstArray < myList.size(); firstArray++){
                for(int secondArray = 0; secondArray < myList.get(firstArray).size(); secondArray++){
                    // Checks the first element of the second ArrayList to see if the store name is found
                    if(myList.get(firstArray).get(secondArray).getCouponNumber().equals(couponNumber)){
                        return secondArray;
                    }
                }
            }
		return -1;
	}
        
        // Print function to help me check my progress
	public void printAll(){
		for(int i = 0; i < myList.size(); i++){
                    for(Information object : myList.get(i)){
			System.out.println(object.toString());
                    }
                    System.out.println();
		}
	}
}
