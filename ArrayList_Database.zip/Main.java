package main;

public class Main{
	public static void main(String args[]){
            Database object = new Database();
            object.read("stores.txt");
            object.write("output.txt");
        }
}