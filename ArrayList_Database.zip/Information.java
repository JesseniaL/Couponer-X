package main;

public class Information {
    private String image;
	private String expirationDate;
	private String couponNumber;
	private String storeName;

	// Constructor with 3 parameters
	Information(String image, String expirationDate, String couponNumber){
            this.image = image;
            this.expirationDate = expirationDate;
            this.couponNumber = couponNumber;
	}
	// Constructor with 4 parameters
	Information(String storeName, String image, String expirationDate, String couponNumber){
            this.storeName = storeName;	
            this.image = image;
            this.expirationDate = expirationDate;
            this.couponNumber = couponNumber;
	}
	Information(String storeName){
            this.storeName = storeName;
	}
	// Setters
	public void setImage(String image){ this.image = image; }
	public void setExpirationDate(String expirationDate){ this.expirationDate = expirationDate; }
	public void setCouponNumber(String couponNumber){ this.couponNumber = couponNumber; }
	public void setStoreName(String storeName){ this.storeName = storeName; }
	// Getters
	public String getImage(){ return image; }
	public String getExpirationDate(){ return expirationDate; }
	public String getCouponNumber(){ return couponNumber; }
	public String getStoreName(){ return storeName; }
	// Returns the string of the object's member variables
	public String toString(){
		return this.getStoreName() + " " + this.getImage() + " " + this.getExpirationDate() + " " + this.getCouponNumber();
	}
}
