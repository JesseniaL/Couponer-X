Android-OCRSample using tesseract
====

This is an example Android application for OCR. The current version uses [Text Recognition API Overview](https://developers.google.com/vision/text-overview) while the old version used Tesseract.

